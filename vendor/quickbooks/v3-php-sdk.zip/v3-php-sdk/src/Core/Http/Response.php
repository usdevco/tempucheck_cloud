<?php
namespace QuickBooksOnline\API\Core\Http;

/**
 * Contains properties about how the response from ids server is requested for like Compression, Serialization etc.
 */
class Response extends RequestResponse
{
}
