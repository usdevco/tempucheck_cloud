<?php
namespace QuickBooksOnline\API\Core\Http\Serialization;

/**
 * Represents entities or datatype which were unable to recognize from meta data
 */
class UnknownEntity extends AbstractEntity
{
}
