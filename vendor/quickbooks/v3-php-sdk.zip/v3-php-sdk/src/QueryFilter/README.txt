Although most of this SDK is based on the .NET SDK, this particular
folder is modeled after the Java SDK
