<?php
namespace QuickBooksOnline\API\Security;

/**
* Base class that all authentication mechanisms should inherit from
*
* Base class that all authentication mechanisms should inherit from,
* especially the OAuth authentication classes.
*
*/
class RequestValidator
{
}
